<?php
//set default values
$name = '';
$email = '';
$phone = '';
$message = 'Enter some data and click on the Submit button.';

//process
$action = filter_input(INPUT_POST, 'action');

switch ($action) {
    case 'process_data':
        $name = filter_input(INPUT_POST, 'name');
        $email = filter_input(INPUT_POST, 'email');
        $phone = filter_input(INPUT_POST, 'phone');

        //clean up spaces in inputted data
        $name = trim($name); //trim name
        $email = trim($email); //trim email
        $phone = trim($phone); // trim phone number
        
        //check the name
        //if name is empty a message is displayed to the user
        if (empty($name)){
            $message = 'You must enter a name.'; //message displayed to user
            break;
        }
        
        //first letter capitilization
        $name = strtolower($name);
        $name = ucwords($name);
        
        //pull first name from the ful name
        $i = strpos($name, ' ');
        //sees if user only entered full name or just first
        if ($i === false){
            $first_name = $name;
        }else {
            $first_name = substr($name, 0, $i);
        }
        
        //get all parts of name and split them up seperately 
        $parts = explode(' ', $name);
        $first__name = array_shift($parts);
        $last_name = array_pop($parts);
        $middle_name = trim(implode(' ', $parts));
        
        //check user email
        //sees if the user entered an email
        if (empty($email)){
            $message = 'Please enter a valid email address.';
            break;
        //sees if users email has a @ in it
        }else if(strpos($email, '@') === false){
            $message = 'The email must have the @ symbol.';
            break;
        //sees if email has a period/dot in it
        }else if(strpos($email, '.') === false){
            $message = 'The email must have a dot character.';
            break;
        }
        
        //clean up phone number
        $phone = str_replace('-', '', $phone);
        $phone = str_replace(')', '', $phone);
        $phone = str_replace('(', '', $phone);
        $phone = str_replace(' ', '', $phone);
        
        //check the phone #
        //does it have 7 digits
        if(strlen($phone) < 7){
            $message = 'The phone number must have seven digits to it.';
            break;
        }
        
        //phone number formatting
        if (strlen($phone) == 7) {
            $part1 = substr($phone, 0, 3);
            $part2 = substr($phone, 3);
            $phone =  $part2;
        } else {
            $part1 = substr($phone, 0, 3);
            $part2 = substr($phone, 3, 3);
            $part3 = substr($phone, 6);
            $phone = $part1 . '-' . $part2 . '-' . $part3;
        }

        
        //message when submitted 
        $message = 
                "Hello $first_name, \n\n" .
                "Thank you for entering this data:\n\n" .
                "First name: $first_name\n" .
                "Middle name: $middle_name\n" .
                "Last name: $last_name\n" .
                "Email: $email\n" .
                "Area Code: $part1\n" .
                "Phone: $part2  -  $part3 \n";
        break;
        
        
       
}
include 'string_tester.php';
?>